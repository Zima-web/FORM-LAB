// Part B - JavaScript Validation

const form = document.getElementById("reg-form");
const statusMsg = document.getElementById("status");

// Show error message
function showError(input, message) {
    const errorEl = document.getElementById(input.id + "-error");

    errorEl.textContent = message;
    input.classList.toggle("invalid", message !== "");

    if (message !== "") {
        input.setAttribute("aria-invalid", "true");
    } else {
        input.removeAttribute("aria-invalid");
    }
}

// B2.1 - Validate Name
function validateName(value) {
    if (value.trim() === "") {
        return "Please enter your full name.";
    }

    if (value.trim().length < 3) {
        return "Your name must be at least 3 characters.";
    }

    return "";
}

// B2.2 - Validate Student ID
function validateStudentId(value) {
    if (!/^HD\d-\d{3}$/.test(value)) {
        return "Use the format HD3-017.";
    }

    return "";
}

// Validate Email
function validateEmail(value) {
    if (value.trim() === "") {
        return "Please enter your email.";
    }

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) {
        return "Enter an email like name@example.com.";
    }

    return "";
}

// Validate Phone
function validatePhone(value) {
    if (!/^07\d{8}$/.test(value)) {
        return "Enter 10 digits starting with 07, e.g. 0771234567.";
    }

    return "";
}

// Validate Workshop
function validateWorkshop(value) {
    if (value === "") {
        return "Please choose a workshop.";
    }

    return "";
}

// Validate Guests
function validateGuests(value) {
    const number = Number(value);

    if (!Number.isInteger(number) || number < 0 || number > 3) {
        return "Guests must be a whole number from 0 to 3.";
    }

    return "";
}

// B2 - Connect validation rules
const rules = {
    "full-name": validateName,
    "student-id": validateStudentId,
    "email": validateEmail,
    "phone": validatePhone,
    "workshop": validateWorkshop,
    "guests": validateGuests
};

// Check each field
function checkField(input) {
    const message = rules[input.id](input.value);
    showError(input, message);
    return message === "";
}

// B2 - Check form when submitting
form.addEventListener("submit", (e) => {
    e.preventDefault();

    let firstBad = null;

    for (const id in rules) {
        const input = document.getElementById(id);

        input.setAttribute("aria-describedby", `${id}-error`);

        if (!checkField(input) && firstBad === null) {
            firstBad = input;
        }
    }

    if (firstBad) {
        firstBad.focus();
        statusMsg.textContent = "Please fix the errors shown in red.";
        return;
    }

    statusMsg.textContent = "Registration complete!";
    form.reset();
});

// B3 - Live feedback
for (const id in rules) {
    const input = document.getElementById(id);

    input.addEventListener("blur", () => {
        input.dataset.touched = "yes";
        checkField(input);
    });

    input.addEventListener("input", () => {
        if (input.dataset.touched) {
            checkField(input);
        }
    });
}