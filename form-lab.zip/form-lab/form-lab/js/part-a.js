// Task A1: Submit Event

const form = document.getElementById("reg-form");

form.addEventListener("submit", (e) => {
    e.preventDefault();
    console.log("Form submitted");
});


// Task A2: Reading Values

const nameInput = document.getElementById("full-name");
const guestsInput = document.getElementById("guests");

const name = nameInput.value.trim();
const guests = Number(guestsInput.value);

const data = Object.fromEntries(new FormData(form));

console.log(data);


// Task A3: Registration Summary

const status = document.getElementById("status");
const summary = document.getElementById("summary");

form.addEventListener("submit", (e) => {
    e.preventDefault();

    const name = document.getElementById("full-name").value.trim();

    const workshopSelect = document.getElementById("workshop");
    const workshop =
        workshopSelect.options[workshopSelect.selectedIndex].text;

    const session =
        document.querySelector('input[name="session"]:checked').value;

    const guests = Number(document.getElementById("guests").value);

    const laptop = document.getElementById("laptop").checked;

    console.log(Object.fromEntries(new FormData(form)));

    summary.textContent = "";

    const heading = document.createElement("h2");
    heading.textContent = "Registration received";

    const list = document.createElement("ul");

    const values = [
        `Name: ${name}`,
        `Workshop: ${workshop}`,
        `Session: ${session}`,
        `Guests: ${guests}`,
        `Own laptop: ${laptop ? "Yes" : "No"}`
    ];

    values.forEach((value) => {
        const li = document.createElement("li");
        li.textContent = value;
        list.appendChild(li);
    });

    summary.append(heading, list);

    status.textContent = `Thank you, ${name}!`;

    form.reset();
});